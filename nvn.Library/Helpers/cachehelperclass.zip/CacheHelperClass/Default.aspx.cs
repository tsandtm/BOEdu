﻿using System;
using System.Collections.Generic;
using System.Web.UI;

public partial class _Default : Page
{
    protected void Button1_Click(object sender, EventArgs e)
    {
        string key = "NewUserCount";
        int i;

        if (!CacheHelper.Get(key, out i))
        {
            i = DataAccess.GetNewUserCout();
            CacheHelper.Add(i, key);
            ResultMessage.Text =
                string.Format("UserCount [Value Type = {0}] not found but retrieved and now added to cache.", i);
        }
        else
        {
            ResultMessage.Text = string.Format("UserCount [Value Type = {0}] pulled from cache.", i);
        }
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        string key = "EmployeeList";
        List<Employee> employees;

        if (!CacheHelper.Get(key, out employees))
        {
            employees = DataAccess.GetEmployeeList();
            CacheHelper.Add(employees, key);
            ResultMessage.Text =
                string.Format("Employees [Reference Type Count = {0}] not found but retrieved and now added to cache.",
                              employees.Count);
        }
        else
        {
            ResultMessage.Text = string.Format("Employees [Reference Type Count = {0}] pulled from cache.",
                                               employees.Count);
        }
    }

    protected void Button3_Click(object sender, EventArgs e)
    {
        string key = "NewUserCount";

        if (CacheHelper.Exists(key))
        {
            CacheHelper.Clear(key);
        }

        string key2 = "EmployeeList";

        // Note, you really don't need to do the Exist(s) check 
        // when removing the item from cache.  It's a safe operation even if it 
        // doesn't exist.
        CacheHelper.Clear(key2);

        string result = "Cache has been cleared.";

        if (CacheHelper.Exists(key) || CacheHelper.Exists(key2))
        {
            result = "It didn't work.";
        }

        ResultMessage.Text = result;
    }
}