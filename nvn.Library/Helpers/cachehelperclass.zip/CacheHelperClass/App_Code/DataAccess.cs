﻿using System;
using System.Collections.Generic;

/// <summary>
/// Summary description for DataAccess
/// </summary>
public class DataAccess
{
    public static List<Employee> GetEmployeeList()
    {
        return new List<Employee>
                   {
                       new Employee {FirstName = "Ben", LastName = "Griswold", ID = 1},
                       new Employee {FirstName = "Bill", LastName = "Gates", ID = 2}
                   };
    }

    public static int GetNewUserCout()
    {
        var r = new Random();
        return r.Next(1, 10000);
    }
}